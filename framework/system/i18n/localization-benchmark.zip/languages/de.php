<?php

$strings = array(

	"Title" => "Hallo Welt!",
	"Heading" => "PHP Lokalisierungs-Benchmark",
	"WelcomeParagraph" => "Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden. Dies ist eine Testseite zum Vergleichen der verschiedenen Lokalisierungs-Methoden."

);

?>